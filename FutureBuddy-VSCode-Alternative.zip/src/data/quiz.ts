import { CAREERS, type Career, type TraitKey } from "./careers";

export interface QuizOption {
  label: string;
  scores: Partial<Record<TraitKey, number>>; // 0-10 per trait
}

export interface QuizQuestion {
  id: number;
  question: string;
  category: string;
  options: QuizOption[];
}

export const QUIZ_QUESTIONS: QuizQuestion[] = [
  {
    id: 1,
    category: "Logical Thinking",
    question: "You are given a puzzle with no clear instructions. What do you do first?",
    options: [
      { label: "Break it into smaller logical steps", scores: { analytical: 10, problemSolving: 8, technical: 6 } },
      { label: "Try different approaches until something works", scores: { problemSolving: 8, creativity: 6, technical: 4 } },
      { label: "Ask a friend to solve it with me", scores: { communication: 8, leadership: 5 } },
      { label: "Look for a similar solved example", scores: { analytical: 5, interest: 4, technical: 3 } },
    ],
  },
  {
    id: 2,
    category: "Problem Solving",
    question: "A project you are working on fails one day before submission. Your reaction?",
    options: [
      { label: "Debug calmly and find the root cause", scores: { problemSolving: 10, technical: 7, analytical: 7 } },
      { label: "Rebuild a simpler version quickly", scores: { problemSolving: 8, creativity: 6 } },
      { label: "Coordinate the team and divide the fix", scores: { leadership: 9, communication: 8 } },
      { label: "Ask the mentor for guidance immediately", scores: { communication: 6, analytical: 3 } },
    ],
  },
  {
    id: 3,
    category: "Communication",
    question: "How comfortable are you presenting an idea in front of 50 people?",
    options: [
      { label: "Very comfortable, I enjoy it", scores: { communication: 10, leadership: 8 } },
      { label: "Comfortable with preparation", scores: { communication: 7, leadership: 5 } },
      { label: "Nervous but I can manage", scores: { communication: 4 } },
      { label: "I prefer written communication", scores: { technical: 5, analytical: 5, communication: 2 } },
    ],
  },
  {
    id: 4,
    category: "Creativity",
    question: "Which activity sounds most enjoyable to you?",
    options: [
      { label: "Designing a poster, app screen or brand identity", scores: { creativity: 10, interest: 6 } },
      { label: "Writing code for a new feature", scores: { technical: 10, problemSolving: 6 } },
      { label: "Analysing data to find a pattern", scores: { analytical: 10, problemSolving: 5 } },
      { label: "Organising an event for your college", scores: { leadership: 10, communication: 8 } },
    ],
  },
  {
    id: 5,
    category: "Leadership",
    question: "In a group project, which role do you naturally take?",
    options: [
      { label: "Team leader who plans and assigns work", scores: { leadership: 10, communication: 8 } },
      { label: "The one who builds the technical part", scores: { technical: 10, problemSolving: 6 } },
      { label: "The researcher who gathers information", scores: { analytical: 9, interest: 5 } },
      { label: "The presenter who explains it to others", scores: { communication: 10, creativity: 5 } },
    ],
  },
  {
    id: 6,
    category: "Technical Interest",
    question: "How interested are you in learning new technology and tools?",
    options: [
      { label: "Extremely interested, I explore on my own", scores: { technical: 10, interest: 10 } },
      { label: "Interested if it helps my career", scores: { technical: 7, interest: 7 } },
      { label: "Neutral — I prefer people-focused work", scores: { communication: 7, leadership: 5, technical: 3 } },
      { label: "Not interested at all", scores: { creativity: 4, communication: 4, technical: 1 } },
    ],
  },
  {
    id: 7,
    category: "Mathematical Ability",
    question: "How do you feel about mathematics and numbers?",
    options: [
      { label: "I am strong and enjoy solving problems", scores: { analytical: 10, technical: 7, problemSolving: 7 } },
      { label: "I am comfortable with practice", scores: { analytical: 7, problemSolving: 5 } },
      { label: "Average — I manage when required", scores: { analytical: 4 } },
      { label: "I prefer theory and language subjects", scores: { communication: 8, creativity: 6, analytical: 2 } },
    ],
  },
  {
    id: 8,
    category: "Analytical Thinking",
    question: "You are given a large spreadsheet of sales data. What excites you?",
    options: [
      { label: "Finding trends and building a report", scores: { analytical: 10, technical: 6 } },
      { label: "Automating it with a script", scores: { technical: 10, problemSolving: 8 } },
      { label: "Turning it into a visual story", scores: { creativity: 8, communication: 8, analytical: 6 } },
      { label: "Using it to plan business strategy", scores: { leadership: 9, analytical: 7 } },
    ],
  },
  {
    id: 9,
    category: "Teamwork",
    question: "What describes your working style best?",
    options: [
      { label: "I work best collaborating with a team", scores: { communication: 9, leadership: 7 } },
      { label: "I prefer deep focused solo work", scores: { technical: 8, analytical: 7 } },
      { label: "A mix of both depending on the task", scores: { communication: 6, technical: 6, problemSolving: 5 } },
      { label: "I like guiding juniors while working", scores: { leadership: 10, communication: 8 } },
    ],
  },
  {
    id: 10,
    category: "Decision Making",
    question: "How do you usually make important decisions?",
    options: [
      { label: "With data and careful analysis", scores: { analytical: 10, problemSolving: 7 } },
      { label: "Quickly, based on experience and instinct", scores: { leadership: 9, problemSolving: 6 } },
      { label: "After discussing with people I trust", scores: { communication: 9, leadership: 5 } },
      { label: "By exploring creative alternatives", scores: { creativity: 9, problemSolving: 6 } },
    ],
  },
  {
    id: 11,
    category: "Patience",
    question: "A task requires months of repeated practice before results appear. You would:",
    options: [
      { label: "Stay consistent — long-term goals motivate me", scores: { interest: 10, problemSolving: 7, analytical: 6 } },
      { label: "Stay if progress is measurable", scores: { analytical: 7, interest: 6 } },
      { label: "Prefer tasks with faster visible results", scores: { creativity: 7, communication: 5 } },
      { label: "Switch to something more dynamic", scores: { leadership: 6, creativity: 6, interest: 3 } },
    ],
  },
  {
    id: 12,
    category: "Learning Ability",
    question: "How do you learn a completely new subject best?",
    options: [
      { label: "Hands-on practice and building projects", scores: { technical: 10, problemSolving: 8 } },
      { label: "Structured courses and books", scores: { analytical: 8, interest: 7 } },
      { label: "Discussion, teaching others and group study", scores: { communication: 10, leadership: 6 } },
      { label: "Visual content and experimentation", scores: { creativity: 9, interest: 6 } },
    ],
  },
  {
    id: 13,
    category: "Interest in Science",
    question: "How interested are you in science, biology and research?",
    options: [
      { label: "Very interested — I love experiments and discovery", scores: { analytical: 9, interest: 10, problemSolving: 6 } },
      { label: "Interested in applied science and engineering", scores: { technical: 9, analytical: 7, interest: 7 } },
      { label: "Slightly interested", scores: { interest: 4, analytical: 4 } },
      { label: "Not interested — I prefer business or creative fields", scores: { leadership: 7, creativity: 7, communication: 6 } },
    ],
  },
  {
    id: 14,
    category: "Interest in Technology",
    question: "Which of these would you enjoy building the most?",
    options: [
      { label: "A mobile or web application", scores: { technical: 10, problemSolving: 7, interest: 8 } },
      { label: "A machine, circuit or robot", scores: { technical: 9, analytical: 7, problemSolving: 7 } },
      { label: "A brand, campaign or design system", scores: { creativity: 10, communication: 7 } },
      { label: "A business or organisation", scores: { leadership: 10, communication: 8 } },
    ],
  },
  {
    id: 15,
    category: "Interest in Public Service",
    question: "How appealing is a government or public service career to you?",
    options: [
      { label: "Very appealing — I want to serve the nation", scores: { leadership: 10, communication: 8, interest: 9 } },
      { label: "Appealing for stability and respect", scores: { leadership: 6, analytical: 6, interest: 6 } },
      { label: "I prefer private sector growth and pay", scores: { technical: 7, problemSolving: 6, interest: 6 } },
      { label: "I want to build my own business", scores: { leadership: 9, creativity: 9, problemSolving: 7 } },
    ],
  },
];

export const TRAIT_LABELS: Record<TraitKey, string> = {
  technical: "Technical Ability",
  analytical: "Analytical Ability",
  communication: "Communication",
  creativity: "Creativity",
  leadership: "Leadership",
  problemSolving: "Problem Solving",
  interest: "Career Interest",
};

export type TraitScores = Record<TraitKey, number>;

const TRAIT_KEYS: TraitKey[] = [
  "technical",
  "analytical",
  "communication",
  "creativity",
  "leadership",
  "problemSolving",
  "interest",
];

/** Convert selected option indexes into 0-100 trait scores. */
export function scoreQuiz(answers: number[]): { traits: TraitScores; total: number } {
  const raw: TraitScores = {
    technical: 0,
    analytical: 0,
    communication: 0,
    creativity: 0,
    leadership: 0,
    problemSolving: 0,
    interest: 0,
  };
  const max: TraitScores = { ...raw };

  QUIZ_QUESTIONS.forEach((q, i) => {
    const chosen = q.options[answers[i] ?? 0];
    const best = TRAIT_KEYS.reduce(
      (acc, key) => {
        acc[key] = Math.max(...q.options.map((o) => o.scores[key] ?? 0));
        return acc;
      },
      {} as TraitScores,
    );
    TRAIT_KEYS.forEach((key) => {
      raw[key] += chosen?.scores[key] ?? 0;
      max[key] += best[key];
    });
  });

  const traits = TRAIT_KEYS.reduce((acc, key) => {
    acc[key] = max[key] > 0 ? Math.round((raw[key] / max[key]) * 100) : 0;
    return acc;
  }, {} as TraitScores);

  const total = Math.round(TRAIT_KEYS.reduce((s, k) => s + traits[k], 0) / TRAIT_KEYS.length);
  return { traits, total };
}

export interface CareerMatch {
  slug: string;
  name: string;
  category: string;
  score: number;
  reason: string;
}

/** Match trait scores against each career's ideal profile. */
export function matchCareers(
  traits: TraitScores,
  opts: { interestedField?: string | null; education?: string | null } = {},
): CareerMatch[] {
  const results = CAREERS.map((career) => {
    const keys = Object.keys(career.traits) as TraitKey[];
    let weighted = 0;
    let weightSum = 0;
    keys.forEach((k) => {
      const ideal = career.traits[k] ?? 0;
      const got = traits[k];
      const weight = ideal / 100;
      const closeness = 100 - Math.max(0, ideal - got) * 1.1 - Math.max(0, got - ideal) * 0.15;
      weighted += Math.max(0, closeness) * weight;
      weightSum += weight;
    });
    let score = weightSum ? weighted / weightSum : 0;
    if (opts.interestedField && career.category === opts.interestedField) score += 6;
    score = Math.max(35, Math.min(98, Math.round(score)));
    return { slug: career.slug, name: career.name, category: career.category, score, reason: buildReason(career, traits) };
  });

  return results.sort((a, b) => b.score - a.score);
}

function buildReason(career: Career, traits: TraitScores): string {
  const keys = (Object.keys(career.traits) as TraitKey[])
    .filter((k) => (career.traits[k] ?? 0) >= 70)
    .sort((a, b) => (career.traits[b] ?? 0) - (career.traits[a] ?? 0))
    .slice(0, 3);
  const strong = keys.filter((k) => traits[k] >= 60).map((k) => TRAIT_LABELS[k].toLowerCase());
  const gaps = keys.filter((k) => traits[k] < 60).map((k) => TRAIT_LABELS[k].toLowerCase());
  const parts: string[] = [];
  if (strong.length) parts.push(`Your ${strong.join(", ")} scores align well with what this role demands.`);
  if (gaps.length) parts.push(`Improving your ${gaps.join(" and ")} would strengthen this match further.`);
  if (!parts.length) parts.push("This career is a balanced fit with your overall assessment profile.");
  return parts.join(" ");
}
